function showProducts() {
	$("#name").remove();
	$("#cost").remove();
  $("#grid").show();
		   $("#details").hide();
}