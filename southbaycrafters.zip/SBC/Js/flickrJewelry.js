$(document).ready(function() {

var URL = "https://api.flickr.com/services/feeds/photos_public.gne?jsoncallback=?";
var searchInfo = {
	// change this ID to another flickr ID (like your own if you have one) or tag
	tags : "jewelry,handmade,beads",
	format : "json"
};

// change this to specify how many photos you wish to display (max is 20)
var maxPhotos = 5;

$.getJSON(URL,searchInfo,function(data) {

	$.each(data.items,function(i,photo) {
		if (i<maxPhotos) {
			var photoHTML = '<span class="image">';
			photoHTML += '<a href="' + photo.link + '">';
			photoHTML += '<img src="' + photo.media.m.replace('_m','_s') + '"></a>';
			$('#photos').append(photoHTML);	
		}
	}); // end each
}); // end get JSON
			
}); // end ready