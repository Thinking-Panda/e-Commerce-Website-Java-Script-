$(document).ready(function(){
            // Initialize Smart Cart
            $('#smartcart').smartCart({
                                submitSettings: {
                                    submitType: 'paypal' // form, paypal, ajax
                                },
                                toolbarSettings: {
                                    checkoutButtonStyle: 'paypal' // default, paypal, image
                                }
                            });
							
		});