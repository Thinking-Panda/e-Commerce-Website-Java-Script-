$('#contactform').validate({
  rules : {
    fName : 'required',
	lName: 'required',
    
    // Additonal Methods plugin included with jQuery validate
    phone : {
      required : false,
      phoneUS : true
    },
    email : {
      required : true,
      email : true
    },
	msg: 'required',
  }
  
});
$('#mcontactform').validate({
  rules : {
    fName : 'required',
	lName: 'required',
    
    // Additonal Methods plugin included with jQuery validate
    phone : {
      required : false,
      phoneUS : true
    },
    email : {
      required : true,
      email : true
    },
	msg: 'required',
  }
  
});

