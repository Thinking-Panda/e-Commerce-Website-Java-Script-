
   $(document).ready(function(){
	   $("img").click(function(evt){
		   var name = evt.target.id;		
			const prodList=[["Bunny",20,"Images/wood/bunny_medium.jpg","Images/wood/bunny_large.jpg"],
			["Crane",15,"Images/wood/crane_medium.jpg","Images/wood/crane_large.jpg"],
			["Duck",15,"Images/wood/duck_medium.jpg","Images/wood/duck_large.jpg"],
			["Plane",25,"Images/wood/plane_medium.jpg","Images/wood/plane_large.jpg"],
			["Flowers",35,"Images/decorations/flowers_medium.jpg","Images/decorations/flowers_large.jpg"],
			["Shells",20,"Images/decorations/quilled_shell_medium.jpg","Images/decorations/quilled_shell_large.jpg"],
			["Macrame",14.99,"Images/decorations/macrame_medium.jpg","Images/decorations/macrame_large.jpg"],
			["Pink-Necklace",24.99,"Images/jewelry/pink_necklace_medium.jpg","Images/jewelry/pink_necklace_large.jpg"],
			["Emerald-Necklace",24.99,"Images/jewelry/emerald_necklace_medium.jpg","Images/jewelry/emerald_necklace_large.jpg"],
			["Turquoise-Necklace",24.99,"Images/jewelry/turquoise_necklace_medium.jpg","Images/jewelry/turquoise_necklace_large.jpg"]];
			
			 for(let i=0;i<prodList.length;i++){
		  
				if (name == prodList[i][0]){
					$("#ex1 img").attr('src', prodList[i][2]);
					$("#ex1").zoom({url:prodList[i][3]});
					$("#itemName").append('<p id="name">Name: '+prodList[i][0]+'</p>');
					$("#itemCost").append('<p id="cost">Cost: $'+prodList[i][1]+'</p>');
				}
			}
		   $("#grid").hide();
		   $("#details").show();
		
		});
		
	
	});