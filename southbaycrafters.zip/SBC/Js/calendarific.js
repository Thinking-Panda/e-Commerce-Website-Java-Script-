$(document).ready(function() {

					var URL = "https://calendarific.com/api/v2/holidays?&api_key=c864691601ed7863ded7f09931b4dff1347c2e31&country=US&format-json";
					
					var searchInfo = {
						month: date.getMonth()+1,
						year: date.getFullYear(),
						format : "json"
					};
				$.getJSON(URL,searchInfo,function(data) {
				$.each(data.response.holidays,function(i,holi) {
				if(holi.type!="United Nations observance"){
					var d=holi.date.datetime.month+'/'+holi.date.datetime.day;
					var msg='<p>'+d+':'+holi.name+'</p>';
					$('#funCalendar').append(msg);
					}
				}); // end each
				
				}); // end get JSON
				
						
				}); // end ready
				